
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `admin_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` text COLLATE utf8_unicode_ci NOT NULL,
  `module_prefix` text COLLATE utf8_unicode_ci NOT NULL,
  `view` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1:display',
  `created` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1:display',
  `edit` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1:display',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1:display',
  `upload` tinyint(1) DEFAULT '0' COMMENT '1:display',
  `print` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1:display',
  `status` int(11) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL,
  `reports` tinyint(1) NOT NULL DEFAULT '0',
  `report_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0:vendor,trainer:1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_modules` WRITE;
/*!40000 ALTER TABLE `admin_modules` DISABLE KEYS */;
INSERT INTO `admin_modules` VALUES (1,'users','users',1,1,1,1,0,0,1,1,0,0),(2,'master records','master',1,1,1,1,0,0,1,2,0,0),(3,'dashboard','dashboard',1,0,0,0,0,0,1,20,0,0),(4,'permissions','permissions',1,1,1,1,0,0,1,3,0,0),(5,'banner images','bannerImages',1,1,1,1,0,0,1,4,0,0),(6,'logActivity','logActivity',1,0,0,0,0,0,1,21,0,0),(7,'registered Users','registeredUsers',1,1,1,1,0,0,1,5,0,0),(8,'cms Pages','cmsPages',1,0,1,0,0,0,1,12,0,0),(9,'packages','packages',1,1,1,1,0,0,0,7,0,0),(10,'contactus','contactus',1,0,0,0,0,0,1,22,0,0),(11,'language Management','languageManagement',1,1,1,1,0,0,1,8,0,0),(12,'quotation Request','quotationRequest',1,0,0,0,0,0,1,19,0,0),(17,'notifications','notifications',1,1,1,1,0,0,1,9,0,0),(19,'settings','settings',0,0,0,0,0,0,0,19,0,0),(21,'Service Provider','serviceProviders',1,1,1,1,0,0,1,6,0,0),(24,'faq','faq',1,1,1,1,0,0,0,10,0,0);
/*!40000 ALTER TABLE `admin_modules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `backup_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_lists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `file_name` text COLLATE utf8_unicode_ci NOT NULL,
  `file_size` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `backup_lists` WRITE;
/*!40000 ALTER TABLE `backup_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_lists` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `banner_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banner_images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `image` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `banner_images` WRITE;
/*!40000 ALTER TABLE `banner_images` DISABLE KEYS */;
INSERT INTO `banner_images` VALUES (1,'1530088267.png','2018-06-27 08:31:08','2018-06-27 08:31:08'),(2,'1530088287.jpg','2018-06-27 08:31:27','2018-06-27 08:31:27'),(3,'1532348229.png','2018-07-23 12:17:10','2018-07-23 12:17:10');
/*!40000 ALTER TABLE `banner_images` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name_ar` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `icon` text COLLATE utf8_unicode_ci,
  `parent_id` int(10) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Construction','Construction','1530082459.png',0,1,'2018-06-26 03:20:07','2018-06-27 04:24:51'),(2,'Eng and Co.','Eng and Co.','1529998716.png',1,1,'2018-06-26 04:38:36','2018-06-27 04:01:27'),(3,'Painters','Painters','1529998784.png',1,1,'2018-06-26 04:39:44','2018-06-27 04:20:57'),(4,'Furniture and Wood Work','Furniture and Wood Work','1530082853.png',1,1,'2018-06-27 04:00:16','2018-06-27 04:02:21'),(5,'Plumber Work','Plumber Work','1530083067.png',1,1,'2018-06-27 04:04:27','2018-06-27 04:09:29'),(6,'Sanitary','Sanitary','1530083100.png',1,1,'2018-06-27 04:05:00','2018-06-27 04:09:42'),(7,'Air Conditioning','Air Conditioning','1530083171.png',1,1,'2018-06-27 04:06:11','2018-06-27 04:08:19'),(8,'Ready Mix concrete','Ready Mix concrete','1530083199.png',1,1,'2018-06-27 04:06:39','2018-06-27 04:09:03');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `category_additional_applyquotation_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_additional_applyquotation_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) DEFAULT NULL,
  `json_data` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `category_additional_applyquotation_fields` WRITE;
/*!40000 ALTER TABLE `category_additional_applyquotation_fields` DISABLE KEYS */;
INSERT INTO `category_additional_applyquotation_fields` VALUES (1,1,'[{\"order\":1,\"name\":\"Description\",\"type\":\"text\"}]','2018-06-30 12:18:02','2018-07-19 10:51:58');
/*!40000 ALTER TABLE `category_additional_applyquotation_fields` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `category_additional_quotation_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_additional_quotation_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) DEFAULT NULL,
  `json_data` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `category_additional_quotation_fields` WRITE;
/*!40000 ALTER TABLE `category_additional_quotation_fields` DISABLE KEYS */;
INSERT INTO `category_additional_quotation_fields` VALUES (1,1,'[{\"name\":\"checkbox\",\"required\":false,\"order\":1,\"type\":\"checkboxes\",\"options\":[{\"order\":1,\"name\":\"main branch\",\"value\":\"1\"}],\"value\":{}},{\"order\":2,\"name\":\"radio\",\"required\":true,\"type\":\"radio\",\"options\":[{\"order\":1,\"name\":\"Male\",\"value\":\"1\"},{\"order\":2,\"name\":\"Female\",\"value\":\"2\"}]}]','2018-06-30 12:18:02','2018-07-01 13:32:07');
/*!40000 ALTER TABLE `category_additional_quotation_fields` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cc_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cc_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` int(10) unsigned NOT NULL,
  `response_code` bigint(20) DEFAULT NULL,
  `response_desc` text COLLATE utf8_unicode_ci,
  `message` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `receipt_no` bigint(20) DEFAULT NULL,
  `transaction_no` bigint(20) DEFAULT NULL,
  `acquirer_response_code` bigint(20) DEFAULT NULL,
  `auth_id` bigint(20) DEFAULT NULL,
  `batch_no` bigint(20) DEFAULT NULL,
  `card_type` bigint(20) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `amount` decimal(10,3) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cc_payments` WRITE;
/*!40000 ALTER TABLE `cc_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `cc_payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cmspages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmspages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name_ar` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description_en` text COLLATE utf8_unicode_ci,
  `description_ar` text COLLATE utf8_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cmspages` WRITE;
/*!40000 ALTER TABLE `cmspages` DISABLE KEYS */;
INSERT INTO `cmspages` VALUES (1,'about','about','<p>aboutfsadfsa</p>\r\n','<p>aboutdfasf</p>\r\n',1,'2018-06-25 13:21:14','2018-06-25 13:21:14');
/*!40000 ALTER TABLE `cmspages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contactus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contactus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contactus` WRITE;
/*!40000 ALTER TABLE `contactus` DISABLE KEYS */;
/*!40000 ALTER TABLE `contactus` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(128) NOT NULL,
  `name_ar` varchar(250) NOT NULL,
  `country_code` varchar(10) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'KUWAITt','الكويت','965',1,'2017-12-23 21:00:00','2018-06-25 14:19:45'),(4,'UAE','الامارات','971',1,'2018-02-15 17:14:01','2018-03-20 08:46:19'),(5,'SAUDI ARABIA','السعودية','966',1,'2018-02-15 17:15:13','2018-03-20 08:46:14'),(6,'BAHRAIN','البحرين','973',1,'2018-02-15 17:17:37','2018-03-20 08:46:01'),(7,'QATAR','القطر','974',1,'2018-02-15 17:19:23','2018-03-20 08:46:08');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sender_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sender_email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject` text COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `url` text COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `email_templates` WRITE;
/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faq` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `question_en` text COLLATE utf8_unicode_ci,
  `question_ar` text COLLATE utf8_unicode_ci,
  `answer_en` text COLLATE utf8_unicode_ci,
  `answer_ar` text COLLATE utf8_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `faq` WRITE;
/*!40000 ALTER TABLE `faq` DISABLE KEYS */;
/*!40000 ALTER TABLE `faq` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `information` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name_ar` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description_en` text COLLATE utf8_unicode_ci,
  `description_ar` text COLLATE utf8_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `information` WRITE;
/*!40000 ALTER TABLE `information` DISABLE KEYS */;
INSERT INTO `information` VALUES (1,'Building Contract','Building Contract','<p>Building Contract</p>\r\n','<p>Building Contract</p>\r\n',1,'2018-06-25 13:21:14','2018-07-17 08:29:39');
/*!40000 ALTER TABLE `information` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `knet_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `knet_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment_id` int(10) unsigned NOT NULL,
  `amount` decimal(10,3) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `transaction_id` bigint(20) DEFAULT NULL,
  `auth` bigint(20) DEFAULT NULL,
  `reference_id` bigint(20) DEFAULT NULL,
  `result` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `post_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `knet_payments` WRITE;
/*!40000 ALTER TABLE `knet_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `knet_payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `language_management`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `language_management` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `label_en` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `label_ar` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `language_management` WRITE;
/*!40000 ALTER TABLE `language_management` DISABLE KEYS */;
/*!40000 ALTER TABLE `language_management` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `log_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_activities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `method` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `agent` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_type` tinyint(1) DEFAULT NULL COMMENT 'Admin:0,Vendor:1,Trainer:2',
  `vendor_id` int(11) DEFAULT NULL,
  `trainer_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=247 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `log_activities` WRITE;
/*!40000 ALTER TABLE `log_activities` DISABLE KEYS */;
INSERT INTO `log_activities` VALUES (1,'User - afreen has been created by admin','http://localhost/quickapp/admin/users','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-25 12:59:20','2018-06-25 12:59:20'),(2,'Package - Free Package has been created by admin','http://localhost/quickapp/admin/packages','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-25 13:13:29','2018-06-25 13:13:29'),(3,'Package - Free Package has been updated by admin','http://localhost/quickapp/admin/packages/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-25 13:17:31','2018-06-25 13:17:31'),(4,'Package - Free Package has been updated by admin','http://localhost/quickapp/admin/packages/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-25 13:18:27','2018-06-25 13:18:27'),(5,'Package - Free Package has been updated by admin','http://localhost/quickapp/admin/packages/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-25 13:18:49','2018-06-25 13:18:49'),(6,'Package - Free Package has been updated by admin','http://localhost/quickapp/admin/packages/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-25 13:19:02','2018-06-25 13:19:02'),(7,'CmsPage - about has been created by admin','http://localhost/quickapp/admin/cmsPages','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-25 13:21:14','2018-06-25 13:21:14'),(8,'Notification - General has been created by admin','http://localhost/quickapp/admin/notifications','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-25 13:36:23','2018-06-25 13:36:23'),(9,'Country - KUWAITt has been updated by admin','http://localhost/quickapp/admin/countries/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-25 14:19:45','2018-06-25 14:19:45'),(10,'Country - Kuwaitiii has been created by admin','http://localhost/quickapp/admin/countries','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-25 14:23:11','2018-06-25 14:23:11'),(11,'Country - [\"Kuwaitiii\"] has been deleted by admin','http://localhost/quickapp/admin/masters/countries/delete','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-25 14:23:21','2018-06-25 14:23:21'),(12,'Category - construction has been created by admin','http://localhost/quickapp/admin/categories','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 06:20:08','2018-06-26 06:20:08'),(13,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 06:30:03','2018-06-26 06:30:03'),(14,'Category - Sub Const has been created by admin','http://localhost/quickapp/admin/categories','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 07:38:37','2018-06-26 07:38:37'),(15,'Category - Sub Sub Constr has been created by admin','http://localhost/quickapp/admin/categories','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 07:39:44','2018-06-26 07:39:44'),(16,'Category - Sub Const has been updated by admin','http://localhost/quickapp/admin/categories/2','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 09:35:52','2018-06-26 09:35:52'),(17,'Category - Sub Const has been updated by admin','http://localhost/quickapp/admin/categories/2','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 09:36:36','2018-06-26 09:36:36'),(18,'Category - Sub Sub Constr has been updated by admin','http://localhost/quickapp/admin/categories/3','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 09:53:51','2018-06-26 09:53:51'),(19,'Category - Sub Sub Constr has been updated by admin','http://localhost/quickapp/admin/categories/3','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 09:55:57','2018-06-26 09:55:57'),(20,'Category - Sub Sub Constr has been updated by admin','http://localhost/quickapp/admin/categories/3','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 09:56:15','2018-06-26 09:56:15'),(21,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 10:45:38','2018-06-26 10:45:38'),(22,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 10:46:49','2018-06-26 10:46:49'),(23,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 10:49:42','2018-06-26 10:49:42'),(24,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 10:52:18','2018-06-26 10:52:18'),(25,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 10:53:53','2018-06-26 10:53:53'),(26,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 10:57:04','2018-06-26 10:57:04'),(27,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 11:01:22','2018-06-26 11:01:22'),(28,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 11:02:08','2018-06-26 11:02:08'),(29,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 11:05:03','2018-06-26 11:05:03'),(30,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 11:09:44','2018-06-26 11:09:44'),(31,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 11:10:07','2018-06-26 11:10:07'),(32,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 11:10:31','2018-06-26 11:10:31'),(33,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 11:10:55','2018-06-26 11:10:55'),(34,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 11:11:43','2018-06-26 11:11:43'),(35,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 11:12:51','2018-06-26 11:12:51'),(36,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 11:13:50','2018-06-26 11:13:50'),(37,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 11:14:12','2018-06-26 11:14:12'),(38,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 11:15:37','2018-06-26 11:15:37'),(39,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 11:54:26','2018-06-26 11:54:26'),(40,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 12:02:54','2018-06-26 12:02:54'),(41,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 12:06:04','2018-06-26 12:06:04'),(42,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 12:07:27','2018-06-26 12:07:27'),(43,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 12:07:56','2018-06-26 12:07:56'),(44,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 12:12:16','2018-06-26 12:12:16'),(45,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 12:13:45','2018-06-26 12:13:45'),(46,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 12:22:33','2018-06-26 12:22:33'),(47,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 12:22:55','2018-06-26 12:22:55'),(48,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 12:30:51','2018-06-26 12:30:51'),(49,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 13:04:11','2018-06-26 13:04:11'),(50,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 13:11:25','2018-06-26 13:11:25'),(51,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 13:16:36','2018-06-26 13:16:36'),(52,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 13:23:50','2018-06-26 13:23:50'),(53,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 13:26:43','2018-06-26 13:26:43'),(54,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 13:28:54','2018-06-26 13:28:54'),(55,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 13:36:07','2018-06-26 13:36:07'),(56,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 13:36:29','2018-06-26 13:36:29'),(57,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 13:41:55','2018-06-26 13:41:55'),(58,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 13:42:45','2018-06-26 13:42:45'),(59,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 13:46:24','2018-06-26 13:46:24'),(60,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 13:48:01','2018-06-26 13:48:01'),(61,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-26 13:48:23','2018-06-26 13:48:23'),(62,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 06:50:56','2018-06-27 06:50:56'),(63,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 06:53:35','2018-06-27 06:53:35'),(64,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 06:53:59','2018-06-27 06:53:59'),(65,'Category - construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 06:54:19','2018-06-27 06:54:19'),(66,'Category - Furniture and Wood Work has been created by admin','http://localhost/quickapp/admin/categories','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:00:16','2018-06-27 07:00:16'),(67,'Category - Furniture and Wood Work has been updated by admin','http://localhost/quickapp/admin/categories/4','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:00:53','2018-06-27 07:00:53'),(68,'Category - Eng and Co. has been updated by admin','http://localhost/quickapp/admin/categories/2','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:01:28','2018-06-27 07:01:28'),(69,'Category - Furniture and Wood Work has been updated by admin','http://localhost/quickapp/admin/categories/4','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:02:21','2018-06-27 07:02:21'),(70,'Category - Painters has been updated by admin','http://localhost/quickapp/admin/categories/3','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:02:45','2018-06-27 07:02:45'),(71,'Category - Plumber Work has been created by admin','http://localhost/quickapp/admin/categories','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:04:27','2018-06-27 07:04:27'),(72,'Category - Plumber Work has been created by admin','http://localhost/quickapp/admin/categories','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:05:00','2018-06-27 07:05:00'),(73,'Category - Plumber Work has been created by admin','http://localhost/quickapp/admin/categories','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:06:11','2018-06-27 07:06:11'),(74,'Category - Plumber Work has been created by admin','http://localhost/quickapp/admin/categories','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:06:39','2018-06-27 07:06:39'),(75,'Category - Sanitary has been updated by admin','http://localhost/quickapp/admin/categories/6','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:07:18','2018-06-27 07:07:18'),(76,'Category - Sanitary has been updated by admin','http://localhost/quickapp/admin/categories/6','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:07:34','2018-06-27 07:07:34'),(77,'Category - Air Conditioning has been updated by admin','http://localhost/quickapp/admin/categories/7','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:08:03','2018-06-27 07:08:03'),(78,'Category - Air Conditioning has been updated by admin','http://localhost/quickapp/admin/categories/7','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:08:19','2018-06-27 07:08:19'),(79,'Category - Ready Mix concrete has been updated by admin','http://localhost/quickapp/admin/categories/8','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:08:49','2018-06-27 07:08:49'),(80,'Category - Ready Mix concrete has been updated by admin','http://localhost/quickapp/admin/categories/8','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:09:03','2018-06-27 07:09:03'),(81,'Category - Plumber Work has been updated by admin','http://localhost/quickapp/admin/categories/5','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:09:29','2018-06-27 07:09:29'),(82,'Category - Sanitary has been updated by admin','http://localhost/quickapp/admin/categories/6','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:09:42','2018-06-27 07:09:42'),(83,'Category - Painters has been updated by admin','http://localhost/quickapp/admin/categories/3','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:20:58','2018-06-27 07:20:58'),(84,'Category - Construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:24:51','2018-06-27 07:24:51'),(85,'Banner Images has been uploaded by admin','http://localhost/quickapp/admin/bannerImages/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:58:45','2018-06-27 07:58:45'),(86,'Banner Images has been deleted by admin','http://localhost/quickapp/admin/bannerImages/deleteImage/1','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:59:38','2018-06-27 07:59:38'),(87,'Banner Images has been uploaded by admin','http://localhost/quickapp/admin/bannerImages/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 07:59:54','2018-06-27 07:59:54'),(88,'Banner Images has been deleted by admin','http://localhost/quickapp/admin/bannerImages/deleteImage/2','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:01:12','2018-06-27 08:01:12'),(89,'Banner Images has been uploaded by admin','http://localhost/quickapp/admin/bannerImages/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:01:18','2018-06-27 08:01:18'),(90,'Banner Images has been deleted by admin','http://localhost/quickapp/admin/bannerImages/deleteImage/3','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:01:52','2018-06-27 08:01:52'),(91,'Banner Images has been uploaded by admin','http://localhost/quickapp/admin/bannerImages/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:02:04','2018-06-27 08:02:04'),(92,'Banner Images has been deleted by admin','http://localhost/quickapp/admin/bannerImages/deleteImage/4','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:02:17','2018-06-27 08:02:17'),(93,'Banner Images has been uploaded by admin','http://localhost/quickapp/admin/bannerImages/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:02:26','2018-06-27 08:02:26'),(94,'Banner Images has been deleted by admin','http://localhost/quickapp/admin/bannerImages/deleteImage/5','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:02:55','2018-06-27 08:02:55'),(95,'Banner Images has been uploaded by admin','http://localhost/quickapp/admin/bannerImages/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:04:24','2018-06-27 08:04:24'),(96,'Banner Images has been uploaded by admin','http://localhost/quickapp/admin/bannerImages/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:04:43','2018-06-27 08:04:43'),(97,'Banner Images has been uploaded by admin','http://localhost/quickapp/admin/bannerImages/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:05:03','2018-06-27 08:05:03'),(98,'Banner Images has been deleted by admin','http://localhost/quickapp/admin/bannerImages/deleteImage/8','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:06:46','2018-06-27 08:06:46'),(99,'Banner Images has been deleted by admin','http://localhost/quickapp/admin/bannerImages/deleteImage/7','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:06:48','2018-06-27 08:06:48'),(100,'Banner Images has been deleted by admin','http://localhost/quickapp/admin/bannerImages/deleteImage/6','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:07:10','2018-06-27 08:07:10'),(101,'Banner Images has been uploaded by admin','http://localhost/quickapp/admin/bannerImages/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:07:21','2018-06-27 08:07:21'),(102,'Banner Images has been uploaded by admin','http://localhost/quickapp/admin/bannerImages/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:08:07','2018-06-27 08:08:07'),(103,'Banner Images has been uploaded by admin','http://localhost/quickapp/admin/bannerImages/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:09:19','2018-06-27 08:09:19'),(104,'Banner Images has been uploaded by admin','http://localhost/quickapp/admin/bannerImages/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:09:37','2018-06-27 08:09:37'),(105,'Banner Images has been uploaded by admin','http://localhost/quickapp/admin/bannerImages/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:18:07','2018-06-27 08:18:07'),(106,'Banner Images has been uploaded by admin','http://localhost/quickapp/admin/bannerImages/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:18:52','2018-06-27 08:18:52'),(107,'Banner Images has been uploaded by admin','http://localhost/quickapp/admin/bannerImages/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:19:10','2018-06-27 08:19:10'),(108,'Banner Images has been uploaded by admin','http://localhost/quickapp/admin/bannerImages/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:31:08','2018-06-27 08:31:08'),(109,'Banner Images has been uploaded by admin','http://localhost/quickapp/admin/bannerImages/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 08:31:27','2018-06-27 08:31:27'),(110,'RegisteredUser -  has been created by admin','http://localhost/quickapp/admin/registeredUsers','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 09:38:59','2018-06-27 09:38:59'),(111,'RegisteredUser -  has been updated by admin','http://localhost/quickapp/admin/registeredUsers/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 09:49:33','2018-06-27 09:49:33'),(112,'RegisteredUser -  has been updated by admin','http://localhost/quickapp/admin/registeredUsers/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 09:50:06','2018-06-27 09:50:06'),(113,'RegisteredUser -  has been updated by admin','http://localhost/quickapp/admin/registeredUsers/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 09:58:18','2018-06-27 09:58:18'),(114,'RegisteredUser -  has been created by admin','http://localhost/quickapp/admin/serviceProviders','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 14:00:45','2018-06-27 14:00:45'),(115,'RegisteredUser - Shams has been updated by admin','http://localhost/quickapp/admin/serviceProviders/2','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 14:39:12','2018-06-27 14:39:12'),(116,'RegisteredUser - Shams has been updated by admin','http://localhost/quickapp/admin/serviceProviders/2','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 14:40:17','2018-06-27 14:40:17'),(117,'RegisteredUser - Shams has been updated by admin','http://localhost/quickapp/admin/serviceProviders/2','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 14:40:54','2018-06-27 14:40:54'),(118,'RegisteredUser - [null] has been trashed by admin','http://localhost/quickapp/admin/serviceProviders/delete','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 14:41:57','2018-06-27 14:41:57'),(119,'RegisteredUser -  has been restore by admin','http://localhost/quickapp/admin/registeredUsers/trashed/2/restore','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-27 14:42:14','2018-06-27 14:42:14'),(120,'RegisteredUser - Mintra has been created by admin','http://localhost/quickapp/admin/serviceProviders','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-28 07:10:21','2018-06-28 07:10:21'),(121,'RegisteredUser -  has been created by admin','http://localhost/quickapp/admin/registeredUsers','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-28 07:35:24','2018-06-28 07:35:24'),(122,'Service Provider -Mintra Image has been uploaded by admin','http://localhost/quickapp/admin/serviceProviders/3/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-28 09:08:07','2018-06-28 09:08:07'),(123,'Service Provider -Mintra Image has been uploaded by admin','http://localhost/quickapp/admin/serviceProviders/3/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-28 09:10:20','2018-06-28 09:10:20'),(124,'Service Provider -Mintra Image has been uploaded by admin','http://localhost/quickapp/admin/serviceProviders/3/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-28 09:12:50','2018-06-28 09:12:50'),(125,'Service Provider -Mintra Image has been uploaded by admin','http://localhost/quickapp/admin/serviceProviders/3/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-28 09:13:40','2018-06-28 09:13:40'),(126,'Service Provider -Mintra Image has been deleted by admin','http://localhost/quickapp/admin/serviceProviders/deleteImage/3','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-28 09:13:59','2018-06-28 09:13:59'),(127,'Service Provider -Mintra Image has been uploaded by admin','http://localhost/quickapp/admin/serviceProviders/3/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-28 09:14:53','2018-06-28 09:14:53'),(128,'Service Provider -Mintra Image has been deleted by admin','http://localhost/quickapp/admin/serviceProviders/deleteImage/4','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-28 09:15:54','2018-06-28 09:15:54'),(129,'Service Provider -Mintra Image has been uploaded by admin','http://localhost/quickapp/admin/serviceProviders/3/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-28 09:16:11','2018-06-28 09:16:11'),(130,'Service Provider -Mintra Image has been deleted by admin','http://localhost/quickapp/admin/serviceProviders/deleteImage/5','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-06-28 09:16:24','2018-06-28 09:16:24'),(131,'RegisteredUser -  has been created by admin','http://localhost/quickapp/admin/registeredUsers','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-02 09:08:21','2018-07-02 09:08:21'),(132,'Category - Construction has been updated by admin','http://localhost/quickapp/admin/categories/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-03 13:11:07','2018-07-03 13:11:07'),(133,'RegisteredUser - Mintra has been updated by admin','http://localhost/quickapp/admin/serviceProviders/3','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-03 13:14:28','2018-07-03 13:14:28'),(134,'RegisteredUser - Mintra has been updated by admin','http://localhost/quickapp/admin/serviceProviders/3','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-03 13:15:08','2018-07-03 13:15:08'),(135,'RegisteredUser - Mintra has been updated by admin','http://localhost/quickapp/admin/serviceProviders/3','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-03 13:19:53','2018-07-03 13:19:53'),(136,'RegisteredUser - Shams has been updated by admin','http://localhost/quickapp/admin/serviceProviders/2','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-03 13:20:06','2018-07-03 13:20:06'),(137,'RegisteredUser - Makaan has been created by admin','http://localhost/quickapp/admin/serviceProviders','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-03 13:38:30','2018-07-03 13:38:30'),(138,'RegisteredUser - fda has been created by admin','http://localhost/quickapp/admin/serviceProviders','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-03 13:44:19','2018-07-03 13:44:19'),(139,'RegisteredUser - [null] has been trashed by admin','http://localhost/quickapp/admin/serviceProviders/delete','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-03 13:44:30','2018-07-03 13:44:30'),(140,'RegisteredUser - [\"Arshad\"] has been trashed by admin','http://localhost/quickapp/admin/registeredUsers/delete','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-03 13:51:26','2018-07-03 13:51:26'),(141,'RegisteredUser - Arshad has been restore by admin','http://localhost/quickapp/admin/registeredUsers/trashed/1/restore','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-03 13:53:25','2018-07-03 13:53:25'),(142,'Service Provider -Shams Image has been uploaded by admin','http://localhost/benabase/admin/serviceProviders/2/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-04 12:19:29','2018-07-04 12:19:29'),(143,'Service Provider -Shams Image has been uploaded by admin','http://localhost/benabase/admin/serviceProviders/2/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-04 12:19:31','2018-07-04 12:19:31'),(144,'Service Provider -Shams Image has been uploaded by admin','http://localhost/benabase/admin/serviceProviders/2/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-04 12:19:33','2018-07-04 12:19:33'),(145,'Information - Building Contract has been updated by admin','http://localhost/benabase/admin/information/1','PATCH','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-17 08:29:39','2018-07-17 08:29:39'),(146,'Service - Service1 has been created by admin','http://localhost/benabase/admin/services/1','POST','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-17 12:13:43','2018-07-17 12:13:43'),(147,'Service - service has been created by admin','http://localhost/benabase/admin/services/1','POST','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-17 12:18:19','2018-07-17 12:18:19'),(148,'Service - Service2 has been created by admin','http://localhost/benabase/admin/services/1','POST','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-17 12:20:45','2018-07-17 12:20:45'),(149,'Service - Service21 has been updated by admin','http://localhost/benabase/admin/services/1','PATCH','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-17 12:29:28','2018-07-17 12:29:28'),(150,'Service - Service2 has been updated by admin','http://localhost/benabase/admin/services/1/1','PATCH','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-17 12:31:38','2018-07-17 12:31:38'),(151,'Service - [\"Service2\"] has been deleted by admin','http://localhost/benabase/admin/services/delete/1','POST','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-17 12:36:10','2018-07-17 12:36:10'),(152,'Service - service3 has been created by admin','http://localhost/benabase/admin/services/1','POST','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-17 12:36:39','2018-07-17 12:36:39'),(153,'Service - [\"service3\"] has been deleted by admin','http://localhost/benabase/admin/services/delete/1','POST','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-17 12:36:59','2018-07-17 12:36:59'),(154,'Service - Materials Supply has been created by admin','http://localhost/benabase/admin/services/1','POST','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-17 14:01:50','2018-07-17 14:01:50'),(155,'Service - Bricks has been created by admin','http://localhost/benabase/admin/services/2','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 06:35:43','2018-07-18 06:35:43'),(156,'RegisteredUser - Makaan has been updated by admin','http://localhost/benabase/admin/serviceProviders/6','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 09:39:34','2018-07-18 09:39:34'),(157,'RegisteredUser - Mintra has been updated by admin','http://localhost/benabase/admin/serviceProviders/3','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 09:40:03','2018-07-18 09:40:03'),(158,'RegisteredUser - Makaan has been updated by admin','http://localhost/benabase/admin/serviceProviders/6','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 09:40:28','2018-07-18 09:40:28'),(159,'RegisteredUser - Shams has been updated by admin','http://localhost/benabase/admin/serviceProviders/2','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 09:42:36','2018-07-18 09:42:36'),(160,'Service Provider -Shams Service - Bricks has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 11:51:43','2018-07-18 11:51:43'),(161,'Service Provider -Shams Service - Bricks has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 11:56:08','2018-07-18 11:56:08'),(162,'Service Provider -Shams Service - Brick has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:11:00','2018-07-18 12:11:00'),(163,'Service Provider -Shams Service - Brick has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:13:52','2018-07-18 12:13:52'),(164,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:14:46','2018-07-18 12:14:46'),(165,'Service Provider -Shams Service - Bricks has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:15:02','2018-07-18 12:15:02'),(166,'Service Provider -Shams Service - Bricks has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:15:03','2018-07-18 12:15:03'),(167,'Service Provider -Shams Service - Bricksdd has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:15:17','2018-07-18 12:15:17'),(168,'Service Provider -Shams Service - Bricksdd has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:15:17','2018-07-18 12:15:17'),(169,'Service Provider -Shams Service - Bricksdd has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:15:17','2018-07-18 12:15:17'),(170,'Service Provider -Shams Service - Bricks has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:15:59','2018-07-18 12:15:59'),(171,'Service Provider -Shams Service - Bricks has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:15:59','2018-07-18 12:15:59'),(172,'Service Provider -Shams Service - Bricks has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:15:59','2018-07-18 12:15:59'),(173,'Service Provider -Shams Service - Bricks has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:15:59','2018-07-18 12:15:59'),(174,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:16:31','2018-07-18 12:16:31'),(175,'Service Provider -Shams Service - Bricks has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:17:17','2018-07-18 12:17:17'),(176,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:17:29','2018-07-18 12:17:29'),(177,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:17:29','2018-07-18 12:17:29'),(178,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:20:40','2018-07-18 12:20:40'),(179,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:21:42','2018-07-18 12:21:42'),(180,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:25:42','2018-07-18 12:25:42'),(181,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:25:54','2018-07-18 12:25:54'),(182,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:25:54','2018-07-18 12:25:54'),(183,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:26:06','2018-07-18 12:26:06'),(184,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:26:06','2018-07-18 12:26:06'),(185,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:26:06','2018-07-18 12:26:06'),(186,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:28:02','2018-07-18 12:28:02'),(187,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:28:09','2018-07-18 12:28:09'),(188,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:28:10','2018-07-18 12:28:10'),(189,'Service Provider -Shams Service - Cement has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:31:30','2018-07-18 12:31:30'),(190,'Service Provider -Shams Service - Tools has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:37:41','2018-07-18 12:37:41'),(191,'Service Provider -Shams Service - Tools has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:40:31','2018-07-18 12:40:31'),(192,'Service Provider -Shams Service - Tools has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:40:31','2018-07-18 12:40:31'),(193,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:42:30','2018-07-18 12:42:30'),(194,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:44:28','2018-07-18 12:44:28'),(195,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:45:28','2018-07-18 12:45:28'),(196,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:46:11','2018-07-18 12:46:11'),(197,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:46:20','2018-07-18 12:46:20'),(198,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:46:20','2018-07-18 12:46:20'),(199,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:46:28','2018-07-18 12:46:28'),(200,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:46:28','2018-07-18 12:46:28'),(201,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:46:28','2018-07-18 12:46:28'),(202,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:51:45','2018-07-18 12:51:45'),(203,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:51:54','2018-07-18 12:51:54'),(204,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:52:01','2018-07-18 12:52:01'),(205,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:52:41','2018-07-18 12:52:41'),(206,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:53:10','2018-07-18 12:53:10'),(207,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:53:31','2018-07-18 12:53:31'),(208,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:53:39','2018-07-18 12:53:39'),(209,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:55:01','2018-07-18 12:55:01'),(210,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:57:38','2018-07-18 12:57:38'),(211,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 12:58:19','2018-07-18 12:58:19'),(212,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 13:01:01','2018-07-18 13:01:01'),(213,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 13:02:49','2018-07-18 13:02:49'),(214,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 13:02:56','2018-07-18 13:02:56'),(215,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 13:04:45','2018-07-18 13:04:45'),(216,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 13:07:47','2018-07-18 13:07:47'),(217,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 13:08:32','2018-07-18 13:08:32'),(218,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 13:11:44','2018-07-18 13:11:44'),(219,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 13:14:08','2018-07-18 13:14:08'),(220,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 13:14:48','2018-07-18 13:14:48'),(221,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 13:15:11','2018-07-18 13:15:11'),(222,'Service Provider -Shams Service - Brickss has been created by admin','http://localhost/benabase/admin/serviceProviders/2/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 13:15:23','2018-07-18 13:15:23'),(223,'Service Provider -Shams Services - Shams has been deleted by admin','http://localhost/benabase/admin/serviceProviders/2/service/delete','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 13:32:58','2018-07-18 13:32:58'),(224,'Service Provider -Makaan Service - Tools has been created by admin','http://localhost/benabase/admin/serviceProviders/6/addService','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 13:33:53','2018-07-18 13:33:53'),(225,'Service Provider -Makaan Services - Makaan has been deleted by admin','http://localhost/benabase/admin/serviceProviders/6/service/delete','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 13:34:04','2018-07-18 13:34:04'),(226,'RegisteredUser - Shams has been updated by admin','http://localhost/benabase/admin/serviceProviders/2','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 14:14:34','2018-07-18 14:14:34'),(227,'RegisteredUser - Shams has been updated by admin','http://localhost/benabase/admin/serviceProviders/2','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 14:15:35','2018-07-18 14:15:35'),(228,'RegisteredUser - Makaan has been updated by admin','http://localhost/benabase/admin/serviceProviders/6','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-07-18 14:19:31','2018-07-18 14:19:31'),(229,'Banner Images has been uploaded by admin','http://localhost/benabase/admin/bannerImages/images','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',1,0,0,0,'2018-07-23 12:17:10','2018-07-23 12:17:10'),(230,'RegisteredUser - Makaan has been updated by admin','http://localhost/benabase/admin/serviceProviders/6','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',1,0,0,0,'2018-07-29 12:18:34','2018-07-29 12:18:34'),(231,'RegisteredUser - Makaan has been updated by admin','http://localhost/benabase/admin/serviceProviders/6','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',1,0,0,0,'2018-07-29 12:19:50','2018-07-29 12:19:50'),(232,'User - afreen has been updated by admin','http://localhost/benabase/admin/users/5','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-08-04 10:28:53','2018-08-04 10:28:53'),(233,'User - sheikh has been updated by admin','http://localhost/benabase/admin/users/4','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-08-04 11:46:50','2018-08-04 11:46:50'),(234,'User - salman has been updated by admin','http://localhost/benabase/admin/users/3','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-08-04 11:47:37','2018-08-04 11:47:37'),(235,'User - admin has been updated profile by admin','http://localhost/benabase/admin/user/profile','PUT','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-08-04 11:59:22','2018-08-04 11:59:22'),(236,'Permission - Supervisor has been updated by admin','http://localhost/benabase/admin/permissions/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-08-04 12:22:11','2018-08-04 12:22:11'),(237,'Permission - Supervisor has been updated by admin','http://localhost/benabase/admin/permissions/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-08-04 12:29:29','2018-08-04 12:29:29'),(238,'Permission - Supervisor has been updated by admin','http://localhost/benabase/admin/permissions/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-08-04 12:46:19','2018-08-04 12:46:19'),(239,'Permission - Supervisor has been updated by admin','http://localhost/benabase/admin/permissions/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-08-04 12:46:37','2018-08-04 12:46:37'),(240,'Permission - Supervisor has been updated by admin','http://localhost/benabase/admin/permissions/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-08-04 12:50:11','2018-08-04 12:50:11'),(241,'Permission - Supervisor has been updated by admin','http://localhost/benabase/admin/permissions/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-08-04 12:50:27','2018-08-04 12:50:27'),(242,'Permission - Supervisor has been updated by admin','http://localhost/benabase/admin/permissions/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-08-04 12:50:45','2018-08-04 12:50:45'),(243,'Permission - Supervisor has been updated by admin','http://localhost/benabase/admin/permissions/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-08-04 12:53:22','2018-08-04 12:53:22'),(244,'Permission - Supervisor has been updated by admin','http://localhost/benabase/admin/permissions/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-08-04 12:54:22','2018-08-04 12:54:22'),(245,'Permission - Supervisor has been updated by admin','http://localhost/benabase/admin/permissions/1','PATCH','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-08-04 12:57:46','2018-08-04 12:57:46'),(246,'Information - [\"Building Contract\"] has been deleted by admin','http://localhost/benabase/admin/information/delete','POST','::1','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',1,0,0,0,'2018-08-04 13:07:16','2018-08-04 13:07:16');
/*!40000 ALTER TABLE `log_activities` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `send_to` tinyint(1) DEFAULT NULL COMMENT 'All Application Users:0,Registered Users:1,Non-Register Users:2',
  `subject` text COLLATE utf8_unicode_ci,
  `subject_ar` text COLLATE utf8_unicode_ci,
  `message` text COLLATE utf8_unicode_ci,
  `message_ar` text COLLATE utf8_unicode_ci,
  `link` text COLLATE utf8_unicode_ci,
  `notification_date` datetime DEFAULT NULL,
  `sent_status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,0,'General','General','General','General','','2018-06-26 16:35:00',0,'2018-06-25 13:36:23','2018-06-25 13:36:23');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name_ar` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `num_points` int(11) NOT NULL COMMENT 'Unlimited Inquires :0',
  `price` decimal(10,3) NOT NULL,
  `num_days` int(11) NOT NULL,
  `expired_notify_duration` int(11) NOT NULL,
  `description_en` text COLLATE utf8_unicode_ci,
  `description_ar` text COLLATE utf8_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `has_offer` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `packages` WRITE;
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
INSERT INTO `packages` VALUES (1,'Free Package','Free Package',0,0.000,365,5,'Free Package','Free Package',1,0,'2018-06-25 13:13:29','2018-06-25 13:19:02');
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `payment_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subscriber_id` int(10) unsigned DEFAULT NULL,
  `package_id` int(10) unsigned DEFAULT NULL,
  `reference_id` bigint(20) DEFAULT NULL,
  `amount` decimal(10,3) NOT NULL,
  `post_date` date DEFAULT NULL,
  `result` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payid` bigint(20) unsigned DEFAULT NULL,
  `card_type` tinyint(1) DEFAULT NULL COMMENT 'KNET:1,CC:2',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_details_subscriber_id_index` (`subscriber_id`),
  KEY `payment_details_package_id_index` (`package_id`),
  KEY `payment_details_payid_index` (`payid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `payment_details` WRITE;
/*!40000 ALTER TABLE `payment_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'Supervisor','[\"master-view\",\"permissions-view\",\"bannerImages-view\",\"languageManagement-view\",\"cmsPages-view\",\"dashboard-view\",\"contactus-view\"]',1,'2018-02-05 15:00:00','2018-08-04 12:54:22'),(2,'Manager','[\"users-create\"]',1,'2018-02-14 00:36:10','2018-02-17 03:42:16'),(3,'users','[\"master-view\",\"master-create\",\"master-edit\",\"master-delete\"]',1,'2018-02-14 03:36:41','2018-02-14 23:59:44'),(4,'Accountant','[\"users-view\"]',1,'2018-02-15 00:00:14','2018-02-15 00:00:14');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `push_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_registration` (
  `id` int(11) NOT NULL,
  `user_id` text COLLATE utf8_unicode_ci NOT NULL,
  `gcm_id` text COLLATE utf8_unicode_ci NOT NULL,
  `mobile_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `imei` text COLLATE utf8_unicode_ci NOT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `created_on` datetime NOT NULL,
  `modified_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `push_registration` WRITE;
/*!40000 ALTER TABLE `push_registration` DISABLE KEYS */;
/*!40000 ALTER TABLE `push_registration` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `push_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_report` (
  `id` int(11) NOT NULL,
  `push_id` text COLLATE utf8_unicode_ci NOT NULL,
  `user_id` text COLLATE utf8_unicode_ci NOT NULL,
  `gcm_status` text COLLATE utf8_unicode_ci NOT NULL,
  `new_registration_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `status` text COLLATE utf8_unicode_ci NOT NULL,
  `delivered_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `push_report` WRITE;
/*!40000 ALTER TABLE `push_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `push_report` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `registered_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registered_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0:user;1:service provider',
  `serviceprovider_type` tinyint(1) DEFAULT '0' COMMENT '0:individual;1:company',
  `fullname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `original_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `categories` text COLLATE utf8_unicode_ci,
  `address` text COLLATE utf8_unicode_ci,
  `location` text COLLATE utf8_unicode_ci,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company_description_en` text COLLATE utf8_unicode_ci,
  `company_description_ar` text COLLATE utf8_unicode_ci,
  `council_specification` text COLLATE utf8_unicode_ci,
  `registration_number` int(10) DEFAULT NULL,
  `instagram_id` text COLLATE utf8_unicode_ci,
  `website_address` text COLLATE utf8_unicode_ci,
  `profile_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ratings` int(11) DEFAULT '0',
  `requirements` text COLLATE utf8_unicode_ci,
  `requirement_viewed` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1:viewed',
  `service_viewed` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1:viewed',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `registered_users_email_unique` (`email`),
  UNIQUE KEY `registered_users_mobile_unique` (`mobile`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `registered_users` WRITE;
/*!40000 ALTER TABLE `registered_users` DISABLE KEYS */;
INSERT INTO `registered_users` VALUES (1,0,0,'Arshad','arshad@gmail.com','6297787ba54529df693c9b80e2820259cf4dd3ea','25825825','99353599',1,NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',0,0,'2018-06-27 09:38:59','2018-07-03 13:53:26',NULL),(2,1,1,NULL,'shams@gmail.com','786177b28e32c85e26c3129fe3849433af909f85','258258','25725725',1,NULL,5,'4,8','fdaf',NULL,'','Shams','fadsf','dsaf','a',25,'#fs','','1530623707.png',NULL,'',1,1,'2018-06-27 14:00:45','2018-07-26 14:24:18',NULL),(3,1,0,NULL,'mintra@gmail.com','43a366ca2d7b7babf54ec2e8c210370136f95665','254254','55885588',1,NULL,1,'5,6','Kuwait City',NULL,'','Mintra','Minta','Minta','A',254,'#mintra','http://minta.com','1530623707.png',NULL,'',1,1,'2018-06-28 07:10:20','2018-07-29 06:49:59',NULL),(4,0,0,'Noor Mohammed','noor@gmail.com','7c4a8d09ca3762af61e59520943dc26494f8941b','123456','89789785',1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',0,0,'2018-06-28 07:35:24','2018-06-28 07:35:24',NULL),(5,0,0,'Salim','salim@gmail.com','7c4a8d09ca3762af61e59520943dc26494f8941b','123456','12345678',1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',0,0,'2018-07-02 09:08:20','2018-07-02 09:08:20',NULL),(6,1,1,NULL,'makaan@gmal.com','7c222fb2927d828af22f592134e8932480637c0d','12345678','25252525',1,NULL,1,'4','Khaian',NULL,'','Makaan','Makaan','Makaan','s',3,'','http://creat.com','1530625109.png',NULL,'fdasf',1,1,'2018-07-03 13:38:29','2018-07-29 12:19:50',NULL),(7,1,1,NULL,'adm@g.com','7c4a8d09ca3762af61e59520943dc26494f8941b','123456','25252578',1,NULL,1,'5,6','d',NULL,'','fda','d','d','w',2,'','','1530625459.png',NULL,'',0,0,'2018-07-03 13:44:19','2018-07-03 13:44:30','2018-07-03 13:44:30');
/*!40000 ALTER TABLE `registered_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `service_provider_additional_quotation_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_provider_additional_quotation_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `service_provider_id` int(10) DEFAULT NULL,
  `json_data` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `service_provider_additional_quotation_fields` WRITE;
/*!40000 ALTER TABLE `service_provider_additional_quotation_fields` DISABLE KEYS */;
INSERT INTO `service_provider_additional_quotation_fields` VALUES (1,3,'[{\"name\":\"civil id\",\"order\":1,\"type\":\"text\"}]','2018-07-18 21:00:00','2018-07-19 10:39:20'),(2,2,'[{\"name\":\"CivilID\",\"required\":true,\"order\":1,\"type\":\"text\"}]','2018-07-19 07:32:07','2018-07-19 07:32:08');
/*!40000 ALTER TABLE `service_provider_additional_quotation_fields` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `service_provider_quotations_applied`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_provider_quotations_applied` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `quotation_id` int(10) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `service_provider_id` text COLLATE utf8_unicode_ci,
  `category_id` int(10) DEFAULT NULL,
  `duration` int(10) DEFAULT NULL COMMENT 'in Days',
  `price` decimal(10,3) DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `images` text COLLATE utf8_unicode_ci,
  `files` text COLLATE utf8_unicode_ci,
  `additional_fields` text COLLATE utf8_unicode_ci,
  `approved_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1:Approved',
  `approved_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `v2_bookings_subscriber_id_index` (`user_id`),
  KEY `v2_bookings_module_id_index` (`duration`),
  KEY `v2_bookings_vendor_id_index` (`price`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `service_provider_quotations_applied` WRITE;
/*!40000 ALTER TABLE `service_provider_quotations_applied` DISABLE KEYS */;
INSERT INTO `service_provider_quotations_applied` VALUES (1,1,5,'2',1,365,5000.000,'Construction','[{\"1\":\"1527494592.png\",\"2\":\"1527494648.png\"}]','[{\"1\":\"1527575687.xlsx\",\"2\":\"1527575717.png\"}]',NULL,1,'2018-07-04','2018-07-02 21:00:00','2018-07-02 21:00:00');
/*!40000 ALTER TABLE `service_provider_quotations_applied` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `serviceprovider_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `serviceprovider_images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `image` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `serviceprovider_images` WRITE;
/*!40000 ALTER TABLE `serviceprovider_images` DISABLE KEYS */;
INSERT INTO `serviceprovider_images` VALUES (1,2,'1530706768.jpg','2018-07-04 12:19:28','2018-07-04 12:19:28'),(2,2,'1530706770.jpg','2018-07-04 12:19:31','2018-07-04 12:19:31'),(3,2,'1530706772.jpg','2018-07-04 12:19:32','2018-07-04 12:19:32');
/*!40000 ALTER TABLE `serviceprovider_images` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned DEFAULT '0',
  `service_provider_id` int(11) unsigned DEFAULT '0',
  `name_en` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_ar` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES (1,1,0,'Materials Supply','Materials Supply',1,'2018-07-17 14:01:50','2018-07-17 14:01:50'),(2,0,2,'Brickss','Bricks',1,'2018-07-18 06:35:43','2018-07-18 06:35:43'),(5,0,2,'Cement','Cement',1,'2018-07-18 12:31:30','2018-07-18 12:31:30');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `left_menu_label_en` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `left_menu_label_ar` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'BenaBase ','Inforamtion','Inforamtion','2018-04-01 18:00:00','2018-04-01 18:00:00');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `subscribers_package_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscribers_package_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subscriber_id` int(10) unsigned DEFAULT NULL,
  `package_id` int(10) unsigned DEFAULT NULL,
  `name_en` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_ar` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description_en` text COLLATE utf8_unicode_ci,
  `description_ar` text COLLATE utf8_unicode_ci,
  `num_days` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `notification_date` date DEFAULT NULL,
  `price` decimal(10,3) NOT NULL,
  `payment_id` int(10) unsigned DEFAULT NULL,
  `num_points` int(10) DEFAULT '0' COMMENT 'Unlimited:0',
  `num_inquiry_received` int(10) unsigned NOT NULL DEFAULT '0',
  `active_status` tinyint(1) DEFAULT '0' COMMENT '0:new package;1:active;2:expired',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subscribers_package_details_subscriber_id_index` (`subscriber_id`),
  KEY `subscribers_package_details_package_id_index` (`package_id`),
  KEY `subscribers_package_details_payment_id_index` (`payment_id`),
  KEY `subscribers_package_details_notification_date_index` (`notification_date`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `subscribers_package_details` WRITE;
/*!40000 ALTER TABLE `subscribers_package_details` DISABLE KEYS */;
INSERT INTO `subscribers_package_details` VALUES (1,2,1,'free package','free package','free package','free package',365,'2018-07-18','2019-07-18','2019-07-13',0.000,NULL,NULL,0,1,'2018-07-18 14:15:34','2018-07-18 14:15:34'),(2,6,1,'free package','free package','free package','free package',365,'2018-07-18','2019-07-18','2019-07-13',0.000,NULL,0,0,1,'2018-07-18 14:19:31','2018-07-18 14:19:31');
/*!40000 ALTER TABLE `subscribers_package_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_request_quotations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_request_quotations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `service_provider_ids` text COLLATE utf8_unicode_ci,
  `service_id` int(255) DEFAULT NULL,
  `category_id` int(10) DEFAULT NULL,
  `location` text COLLATE utf8_unicode_ci,
  `submission_date` date DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `additional_fields` text COLLATE utf8_unicode_ci,
  `images` text COLLATE utf8_unicode_ci,
  `files` text COLLATE utf8_unicode_ci,
  `request_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:All;2:Individual',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `v2_bookings_subscriber_id_index` (`user_id`),
  KEY `v2_bookings_module_id_index` (`service_id`),
  KEY `v2_bookings_vendor_id_index` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_request_quotations` WRITE;
/*!40000 ALTER TABLE `user_request_quotations` DISABLE KEYS */;
INSERT INTO `user_request_quotations` VALUES (1,5,'[\"2\",\"3\"]',1,1,'Salmiya','2018-07-02','Construction',NULL,'[{\"1\":\"1527494592.png\",\"2\":\"1527494648.png\"}]','[{\"1\":\"1527575687.xlsx\",\"2\":\"1527575717.png\"}]',1,'2018-07-01 21:00:00','2018-07-01 21:00:00');
/*!40000 ALTER TABLE `user_request_quotations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
INSERT INTO `user_role` VALUES (1,'superadmin',1),(2,'supervisor',1),(3,'manager',1),(4,'viewer',0),(5,'Employee',1);
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `original_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `civilid` text COLLATE utf8_unicode_ci,
  `mobile` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_role_id` int(11) DEFAULT NULL,
  `permission_id` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Superadmin','admin','sagirhashim@gmail.com','$2y$10$04kIT2GddcLLyGuAe56aF.lWw5GTzRE82kCR2T3AQGPuOzg4HKtOW','1234567',NULL,'12345678',1,2,1,'TBxEQveM612KnY7SO8RuPbcKUhE0XQhwUGDsC9Qd2QxtrZO9M6L0EM3bSH35',NULL,'2018-08-04 12:03:36'),(2,'narendra','narendra','n@gmail.com','$2y$10$ZBRuQSIc5I9AQTNzoUjUQO7j5S.wTjHv1P7M8dzGZc/nWZe8M9P0u','123456','','',2,4,1,'tfScHIAObL0bKqF0bx6xbKiYJ5I03jHVULQ3Qni83sjZaccvIBV3zEDxVlvs','2018-02-27 08:50:56','2018-06-21 07:06:12'),(3,'salman','salman','salman@gmail.com','$2y$10$llQFuPNYhJH.0n98ShGh0e3QfYiEGQ5bv45nA4blW8Cu7Hc1f5U3e','12345','','',5,4,1,NULL,'2018-02-28 05:27:13','2018-08-04 11:47:37'),(4,'sheikh','sheikh','sheikh@gmail.com','$2y$10$d3gIwybRuxbMH6zzsbIV6eOIlBYvYlRuT6dOM6RKhcVv8gZ.XGWYe','234567','','',5,1,1,'p11VmylHn0DufWvbkWuhKX2VIVmMnNjcLswrvm9IhTxmmTz9NsLTP1CBAKvQ','2018-03-15 08:30:21','2018-06-19 12:22:05'),(5,'afreen','afreen','afreen@gmail.com','$2y$10$Ne8kELV9LV6v9gkkwhH1gusIvSST4HyG5IUrkhF5qzl25N1LB3CFe','123456',NULL,'25825825',5,3,1,NULL,'2018-06-25 12:59:20','2018-06-25 12:59:20');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

